import SwiftUI
import UIKit

// MARK: - Model

struct Track: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let imageName: String
    let countryName: String
    let countryFlag: String
    let locationName: String
}

enum TrackData {
    static let tracks: [Track] = [
        Track(name: "SOCHI AUTODROM", imageName: "SOCHI AUTODROM", countryName: "Russia", countryFlag: "🇷🇺", locationName: "Sochi"),
        Track(name: "AUTODROMO NAZIONALE MONZA", imageName: "AUTODROMO NAZIONALE MONZA", countryName: "Italy", countryFlag: "🇮🇹", locationName: "Monza"),
        Track(name: "SILVERSTONE CIRCUIT", imageName: "SILVERSTONE CIRCUIT", countryName: "United Kingdom", countryFlag: "🇬🇧", locationName: "Silverstone"),
        Track(name: "RED BULL RING", imageName: "RED BULL RING", countryName: "Austria", countryFlag: "🇦🇹", locationName: "Spielberg"),
        Track(name: "CIRCUIT DE SPA-FRANCORCHAMPS", imageName: "CIRCUIT DE SPA-FRANCORCHAMPS", countryName: "Belgium", countryFlag: "🇧🇪", locationName: "Stavelot"),
        Track(name: "AUTODROMO ENZO E DINO FERRARI", imageName: "AUTODROMO ENZO E DINO FERRARI", countryName: "Italy", countryFlag: "🇮🇹", locationName: "Imola"),
        Track(name: "AUTÓDROMO HERMANOS RODRÍGUEZ", imageName: "AUTÓDROMO HERMANOS RODRÍGUEZ", countryName: "Mexico", countryFlag: "🇲🇽", locationName: "Mexico City"),
        Track(name: "YAS MARINA CIRCUIT", imageName: "YAS MARINA CIRCUIT", countryName: "United Arab Emirates", countryFlag: "🇦🇪", locationName: "Abu Dhabi"),
        Track(name: "MELBOURNE GRAND PRIX CIRCUIT", imageName: "MELBOURNE GRAND PRIX CIRCUIT", countryName: "Australia", countryFlag: "🇦🇺", locationName: "Melbourne"),
        Track(name: "BAKU CITY CIRCUIT", imageName: "BAKU CITY CIRCUIT", countryName: "Azerbaijan", countryFlag: "🇦🇿", locationName: "Baku"),
        Track(name: "BAHRAIN INTERNATIONAL CIRCUIT", imageName: "BAHRAIN INTERNATIONAL CIRCUIT", countryName: "Bahrain", countryFlag: "🇧🇭", locationName: "Sakhir"),
        Track(name: "AUTÓDROMO JOSÉ CARLOS PACE", imageName: "AUTÓDROMO JOSÉ CARLOS PACE", countryName: "Brazil", countryFlag: "🇧🇷", locationName: "São Paulo"),
        Track(name: "HUNGARORING", imageName: "HUNGARORING", countryName: "Hungary", countryFlag: "🇭🇺", locationName: "Mogyoród"),
        Track(name: "HOCKENHEIMRING", imageName: "HOCKENHEIMRING", countryName: "Germany", countryFlag: "🇩🇪", locationName: "Hockenheim"),
        Track(name: "CIRCUIT DE BARCELONA-CATALUNYA", imageName: "CIRCUIT DE BARCELONA-CATALUNYA", countryName: "Spain", countryFlag: "🇪🇸", locationName: "Montmeló"),
        Track(name: "CIRCUIT GILLES-VILLENEUVE", imageName: "CIRCUIT GILLES-VILLENEUVE", countryName: "Canada", countryFlag: "🇨🇦", locationName: "Montréal"),
        Track(name: "LOSAIL INTERNATIONAL CIRCUIT", imageName: "LOSAIL INTERNATIONAL CIRCUIT", countryName: "Qatar", countryFlag: "🇶🇦", locationName: "Lusail"),
        Track(name: "SHANGHAI INTERNATIONAL CIRCUIT", imageName: "SHANGHAI INTERNATIONAL CIRCUIT", countryName: "China", countryFlag: "🇨🇳", locationName: "Shanghai"),
        Track(name: "LAS VEGAS STREET CIRCUIT", imageName: "LAS VEGAS STREET CIRCUIT", countryName: "United States", countryFlag: "🇺🇸", locationName: "Las Vegas"),
        Track(name: "MIAMI INTERNATIONAL AUTODROME", imageName: "MIAMI INTERNATIONAL AUTODROME", countryName: "United States", countryFlag: "🇺🇸", locationName: "Miami"),
        Track(name: "CIRCUIT DE MONACO", imageName: "CIRCUIT DE MONACO", countryName: "Monaco", countryFlag: "🇲🇨", locationName: "Monte Carlo"),
        Track(name: "CIRCUIT ZANDVOORT", imageName: "CIRCUIT ZANDVOORT", countryName: "Netherlands", countryFlag: "🇳🇱", locationName: "Zandvoort"),
        Track(name: "AUTÓDROMO INTERNACIONAL DO ALGARVE", imageName: "AUTÓDROMO INTERNACIONAL DO ALGARVE", countryName: "Portugal", countryFlag: "🇵🇹", locationName: "Portimão"),
        Track(name: "JEDDAH CORNICHE CIRCUIT", imageName: "JEDDAH CORNICHE CIRCUIT", countryName: "Saudi Arabia", countryFlag: "🇸🇦", locationName: "Jeddah"),
        Track(name: "MARINA BAY STREET CIRCUIT", imageName: "MARINA BAY STREET CIRCUIT", countryName: "Singapore", countryFlag: "🇸🇬", locationName: "Singapore"),
        Track(name: "CIRCUIT OF THE AMERICAS", imageName: "CIRCUIT OF THE AMERICAS", countryName: "United States", countryFlag: "🇺🇸", locationName: "Austin"),
        Track(name: "INTERCITY ISTANBUL PARK", imageName: "INTERCITY ISTANBUL PARK", countryName: "Turkey", countryFlag: "🇹🇷", locationName: "Istanbul"),
        Track(name: "CIRCUIT PAUL RICARD", imageName: "CIRCUIT PAUL RICARD", countryName: "France", countryFlag: "🇫🇷", locationName: "Le Castellet"),
        Track(name: "SUZUKA INTERNATIONAL RACING COURSE", imageName: "SUZUKA INTERNATIONAL RACING COURSE", countryName: "Japan", countryFlag: "🇯🇵", locationName: "Suzuka")
    ]
}

// MARK: - Main Screen (SwiftUI)

struct ContentView: View {
    private let tracks = TrackData.tracks

    @State private var currentIndex: Int = 0
    @State private var query: String = ""
    @State private var isZoomPresented: Bool = false

    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var filteredIndexes: [Int] {
        let q = trimmedQuery
        guard !q.isEmpty else { return [] }
        return tracks.enumerated()
            .filter { $0.element.name.localizedCaseInsensitiveContains(q) }
            .map { $0.offset }
    }

    private var currentTrack: Track {
        tracks[min(max(currentIndex, 0), tracks.count - 1)]
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 8) {
                SearchBar(text: $query, onSubmit: {
                    if let first = filteredIndexes.first {
                        currentIndex = first
                    }
                    endSearch()
                })
                .padding(.horizontal, 8)
                .padding(.top, 6)

                ZStack(alignment: .topLeading) {
                    // Image
                    Image(currentTrack.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.black)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            isZoomPresented = true
                        }

                    // title overlay (top-left)
                    VStack(alignment: .leading, spacing: 6) {
                        Text(currentTrack.name)
                            .foregroundColor(.white)
                            .font(.system(size: 30, weight: .heavy))
                            .lineLimit(2)

                        Text(subtitle(for: currentTrack))
                            .foregroundColor(Color.white.opacity(0.9))
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 14)
                    .background(Color.black.opacity(0.45))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .padding(.leading, 16)
                    .padding(.top, 16)
                }
                .overlay(alignment: .top) {
                    // dropdown results (under search)
                    if !filteredIndexes.isEmpty {
                        TrackSearchResults(
                            indexes: filteredIndexes,
                            tracks: tracks,
                            onPick: { idx in
                                currentIndex = idx
                                endSearch()
                            }
                        )
                        .padding(.horizontal, 12)
                        .padding(.top, 8)
                    }
                }
                .overlay(alignment: .bottom) {
                    // bottom controls
                    HStack {
                        CircleButton(systemName: "chevron.left") {
                            currentIndex = (currentIndex - 1 + tracks.count) % tracks.count
                            endSearch()
                        }

                        Spacer()

                        Text("\(currentIndex + 1) / \(tracks.count)")
                            .foregroundColor(Color.white.opacity(0.95))
                            .font(.system(size: 15, weight: .semibold))
                            .frame(width: 90, height: 28)
                            .background(Color.black.opacity(0.45))
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                        Spacer()

                        CircleButton(systemName: "chevron.right") {
                            currentIndex = (currentIndex + 1) % tracks.count
                            endSearch()
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.bottom, 18)
                }
            }
        }
        .fullScreenCover(isPresented: $isZoomPresented) {
            ZoomScreen(
                imageName: currentTrack.imageName,
                titleText: currentTrack.name,
                isPresented: $isZoomPresented
            )
        }
    }

    private func subtitle(for track: Track) -> String {
        if track.locationName.isEmpty {
            return "\(track.countryFlag) \(track.countryName)"
        }
        return "\(track.countryFlag) \(track.countryName) • \(track.locationName)"
    }

    private func endSearch() {
        query = ""
        hideKeyboard()
    }
}

// MARK: - Search UI

private struct SearchBar: View {
    @Binding var text: String
    let onSubmit: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.white.opacity(0.8))

            TextField("Search track…", text: $text)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .foregroundColor(.white)
                .submitLabel(.search)
                .onSubmit(onSubmit)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 12)
        .background(Color.white.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

private struct TrackSearchResults: View {
    let indexes: [Int]
    let tracks: [Track]
    let onPick: (Int) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                ForEach(indexes, id: \.self) { idx in
                    Button {
                        onPick(idx)
                    } label: {
                        HStack {
                            Text(tracks[idx].name)
                                .foregroundColor(.white)
                                .font(.system(size: 16, weight: .semibold))
                                .padding(.vertical, 12)
                                .padding(.horizontal, 14)
                            Spacer(minLength: 0)
                        }
                    }
                    .buttonStyle(.plain)

                    if idx != indexes.last {
                        Divider().background(Color.white.opacity(0.12))
                    }
                }
            }
        }
        .frame(maxHeight: 260)
        .background(Color.black.opacity(0.75))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

private struct CircleButton: View {
    let systemName: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .foregroundColor(.white)
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 56, height: 56)
                .background(Color.black.opacity(0.55))
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Fullscreen zoom (UIScrollView inside SwiftUI)

struct ZoomScreen: View {
    let imageName: String
    let titleText: String
    @Binding var isPresented: Bool

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()

            if let image = UIImage(named: imageName) {
                ZoomableImageView(image: image)
                    .ignoresSafeArea()
            } else {
                VStack(spacing: 10) {
                    Image(systemName: "photo")
                        .foregroundColor(.white.opacity(0.7))
                        .font(.system(size: 28, weight: .semibold))
                    Text("Image not found in Assets: \(imageName)")
                        .foregroundColor(.white.opacity(0.85))
                        .font(.system(size: 14, weight: .regular))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 16)
                }
            }

            HStack {
                Text(titleText)
                    .foregroundColor(.white)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(1)

                Spacer()

                Button {
                    isPresented = false
                } label: {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                        .font(.system(size: 14, weight: .semibold))
                        .frame(width: 32, height: 32)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 14)
            .frame(height: 44)
            .background(Color.black.opacity(0.55))
            .padding(.top, 0)
        }
    }
}

struct ZoomableImageView: UIViewRepresentable {
    let image: UIImage

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> UIScrollView {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .black
        scrollView.delegate = context.coordinator
        scrollView.bouncesZoom = true
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.contentInsetAdjustmentBehavior = .never

        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true

        scrollView.addSubview(imageView)
        context.coordinator.imageView = imageView
        context.coordinator.scrollView = scrollView

        let doubleTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.onDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        scrollView.addGestureRecognizer(doubleTap)

        return scrollView
    }

    func updateUIView(_ scrollView: UIScrollView, context: Context) {
        context.coordinator.image = image
        context.coordinator.configureZoomToFitIfNeeded()
    }

    final class Coordinator: NSObject, UIScrollViewDelegate {
        weak var scrollView: UIScrollView?
        weak var imageView: UIImageView?
        var image: UIImage?
        private var didSetupZoom = false

        func viewForZooming(in scrollView: UIScrollView) -> UIView? {
            imageView
        }

        func scrollViewDidZoom(_ scrollView: UIScrollView) {
            recenterImage()
        }

        func configureZoomToFitIfNeeded() {
            guard let scrollView, let imageView, let image else { return }

            // apply image
            if imageView.image !== image {
                imageView.image = image
                didSetupZoom = false
            }

            let boundsSize = scrollView.bounds.size
            guard boundsSize.width > 0, boundsSize.height > 0 else { return }

            if !didSetupZoom {
                didSetupZoom = true

                imageView.frame = CGRect(origin: .zero, size: image.size)
                scrollView.contentSize = image.size

                let xScale = boundsSize.width / image.size.width
                let yScale = boundsSize.height / image.size.height
                let minScale = min(xScale, yScale)

                scrollView.minimumZoomScale = minScale
                scrollView.maximumZoomScale = max(minScale * 6.0, 6.0)
                scrollView.zoomScale = minScale
            }

            recenterImage()
        }

        private func recenterImage() {
            guard let scrollView, let imageView else { return }
            let boundsSize = scrollView.bounds.size
            var frameToCenter = imageView.frame

            let horizontalInset = max(0, (boundsSize.width - frameToCenter.size.width) / 2)
            let verticalInset = max(0, (boundsSize.height - frameToCenter.size.height) / 2)

            scrollView.contentInset = UIEdgeInsets(top: verticalInset, left: horizontalInset, bottom: verticalInset, right: horizontalInset)
        }

        @objc func onDoubleTap(_ gr: UITapGestureRecognizer) {
            guard let scrollView, let imageView else { return }

            if scrollView.zoomScale > scrollView.minimumZoomScale + 0.01 {
                scrollView.setZoomScale(scrollView.minimumZoomScale, animated: true)
                return
            }

            let newScale = min(scrollView.zoomScale * 3.0, scrollView.maximumZoomScale)
            let pointInView = gr.location(in: imageView)

            let scrollViewSize = scrollView.bounds.size
            let width = scrollViewSize.width / newScale
            let height = scrollViewSize.height / newScale
            let x = pointInView.x - (width / 2)
            let y = pointInView.y - (height / 2)

            let rect = CGRect(x: x, y: y, width: width, height: height)
            scrollView.zoom(to: rect, animated: true)
        }
    }
}

// MARK: - Small helper

private func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}
