//
//  Hello_There_App.swift
//  Hello There!
//
//  Created by User on 06.02.2026.
//

import SwiftUI

@main
struct HelloThereApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
