//
//  NameEntryView.swift
//  Hello There!
//
//  Created by User on 06.02.2026.
//

import SwiftUI

struct NameEntryView: View {
    @Binding var name: String
    @Binding var emoji: String

    let emojis: [String]

    @Environment(\.dismiss) private var dismiss
    @State private var draftName: String = ""

    var body: some View {
        VStack(spacing: 18) {
            Text("Введите имя")
                .font(.title2)
                .fontWeight(.semibold)

            TextField("Как вас зовут?", text: $draftName)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.words)
                .padding(.horizontal)

            Button {
                let trimmed = draftName.trimmingCharacters(in: .whitespacesAndNewlines)
                name = trimmed
                emoji = emojis.randomElement() ?? "🙂"
                dismiss()
            } label: {
                Text("Готово")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.green.opacity(0.9))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.horizontal)
            }

            Spacer()
        }
        .padding(.top, 40)
        .onAppear {
            draftName = name
        }
    }
}
