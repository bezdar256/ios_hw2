//
//  ContentView.swift
//  Hello There!
//
//  Created by User on 06.02.2026.
//

import SwiftUI

struct ContentView: View {
    @State private var name: String = ""
    @State private var emoji: String = "🙂"

    private let emojis = ["👋", "🙂", "😄", "✨", "🌿", "🚀", "🍀", "🔥", "🫶", "😎", "🌸", "⭐️"]

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text(titleText)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)

                NavigationLink {
                    NameEntryView(name: $name, emoji: $emoji, emojis: emojis)
                } label: {
                    Text("Ввести имя")
                        .font(.headline)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.blue.opacity(0.9))
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }
            .padding()
            .onAppear {
                if emoji == "🙂" {
                    emoji = emojis.randomElement() ?? "🙂"
                }
            }
        }
    }

    private var titleText: String {
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "Hello \(emoji)"
        } else {
            return "Hello, \(name) \(emoji)"
        }
    }
}

#Preview {
    ContentView()
}
